---
name: soir
description: Débrief du soir de la campagne de recherche d'emploi. Coche les tâches, tient le journal, prépare demain. À lancer chaque soir, suivi de ce qui a été fait.
disable-model-invocation: true
---

# /soir

L'utilisateur écrit après la commande ce qu'il a fait, par exemple :
`/soir P1-03 fait, 2 candidatures (Temenos, ELCA), refus Pictet après entretien RH, fatigué`.
S'il n'a rien écrit, pose UNE question : « Qu'as-tu fait aujourd'hui, et as-tu reçu des réponses ? »

## Étapes

1. Coche les tâches terminées dans `data/mission/plan.json` (`done: true`, `done_at` = date du jour), avec `npm run mission -- done <id>` si la commande existe.
2. Pour chaque réponse reçue, classe l'étape : `filtre automatique`, `recruteur`, `technique`, `final`. Rappelle de mettre à jour le statut dans la page Candidatures (ne modifie pas la base toi-même).
3. Mets à jour `data/mission/targets.json` pour les entreprises concernées (statut, prochaine action).
4. Ajoute en haut de `data/mission/journal.md` une entrée :

   ```
   ## AAAA-MM-JJ
   - Fait : …
   - Candidatures : n (entreprises)
   - Réponses : entreprise (étape, issue)
   - Énergie : 1 à 5
   - Blocage : …
   - Demain, la priorité : …
   ```

5. Calcule le cumul de la semaine (`npm run mission -- week` si disponible) et compare-le aux KPI de `plan.json`.
6. Le dimanche : ajoute un bilan de semaine de 5 lignes (tunnel, ce qui a marché, ce qu'on change) et signale si le seuil de diagnostic de MISSION.md est atteint (40 candidatures ciblées).

## Réponse (10 lignes maximum)

- Ce qui est enregistré.
- Le fait concret le plus solide de la journée, tiré du journal (une action réelle, pas un compliment).
- Les 3 priorités de demain.
- Si un refus est arrivé : à quelle étape il a eu lieu et ce que cette étape mesure. Un refus au filtre automatique parle du CV ou du ciblage ; après un entretien technique, de la préparation. Jamais de la valeur de la personne.
- Si l'énergie est à 1 ou 2 deux soirs de suite : propose d'alléger le lendemain.
