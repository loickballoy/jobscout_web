---
name: candidature
description: Prépare UNE candidature ciblée à partir d'une offre (id JobScout ou URL) : go / no-go, choix du CV F ou E, message à une personne nommée. Ne rien inventer.
disable-model-invocation: true
---

# /candidature <id d'offre JobScout ou URL>

## 1. Lire l'offre
Id numérique : lire l'offre dans `data/jobscout.db` (lecture seule, table `offres`). URL : la récupérer, ou demander à l'utilisateur de coller le texte si le site bloque.

## 2. Go / no-go (s'arrêter si no-go, en une phrase)
- Expérience demandée ≤ 2 ans, ou programme graduate / junior.
- Langue : l'allemand ou un autre idiome exigé « courant » → no-go.
- Lieu : Suisse romande, Zurich, ou télétravail depuis la Suisse.
- Au moins 2 exigences clés couvertes par des faits du CV maître.
- Disponibilité compatible avec février ou mars 2027.

## 3. Choisir le CV
F pour banque, négoce, fintech, infrastructure de marché ; E pour cabinet et consulting. La génération se fait dans JobScout (fiche de l'offre → CV) : ne pas réécrire le CV ici.

## 4. Rédiger
- Trouver le profil à contacter : le manager de l'équipe ou un ingénieur de l'équipe (demander à l'utilisateur de confirmer le nom ; ne jamais en inventer).
- Message LinkedIn ou e-mail : 4 phrases au plus. Phrase 1 : le poste visé. Phrase 2 : le fait du CV le plus proche du besoin de l'offre, chiffré. Phrase 3 : le lien avec la Suisse ou l'entreprise, s'il est réel. Phrase 4 : une demande simple (10 minutes d'échange ou transmission du dossier). Aucune flatterie, aucun superlatif.
- Lettre courte seulement si l'offre la demande : 120 à 180 mots, mêmes faits.
- Langue de l'offre (français ou anglais).

## 5. Enregistrer
- Mettre à jour `data/mission/targets.json` (contact, statut `candidature`, prochaine action = relance à J+7 avec la date).
- Rappeler d'enregistrer la candidature dans la page Candidatures de JobScout.

## Règle absolue
Tout fait cité doit exister dans le CV maître, `MISSION.md` ou un README public. Un chiffre absent reste entre crochets et l'utilisateur le complète.
