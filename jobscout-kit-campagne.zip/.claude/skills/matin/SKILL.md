---
name: matin
description: Briefing du matin de la campagne de recherche d'emploi. Donne le plan du jour à partir de data/mission/. À lancer chaque matin.
disable-model-invocation: true
---

# /matin

But : en moins d'une minute de lecture, savoir quoi faire aujourd'hui. Pas de discours.

## Étapes

1. Lis `data/mission/MISSION.md` s'il n'est pas déjà dans le contexte, puis les 3 dernières entrées de `data/mission/journal.md`.
2. Obtiens le plan du jour :
   - si `npm run mission -- today --json` fonctionne, utilise sa sortie ;
   - sinon, lis `data/mission/plan.json` et applique toi-même les « Règles du jour » de `docs/SPEC-mission.md` (date du jour, budget, retards, fenêtres, habitudes, gel).
3. Si la base `data/jobscout.db` existe, compte en lecture seule les candidatures au statut `envoyee` depuis 7 jours ou plus : ce sont les relances du jour.

## Format de la réponse (15 lignes maximum)

- Ligne 1 : date, phase, « J-x avant le 31 janvier ».
- « Si tu ne fais qu'une chose aujourd'hui : … » (la tâche de priorité 1 la plus urgente).
- La liste du soir, dans l'ordre d'exécution, avec les minutes, et le total comparé au budget.
- Les relances dues, s'il y en a.
- Ce qui ne rentre pas dans le budget, sur une ligne « Si tu as du temps ».

## Règles

- Si le journal montre qu'hier rien n'a été fait, dis-le en une phrase neutre et réduis le plan du jour à l'essentiel (priorité 1 uniquement). Pas de reproche, pas d'encouragement creux.
- Une tâche en retard de plus de 3 jours : propose de la redécouper ou de déplacer sa fenêtre, mais ne modifie `plan.json` qu'après accord explicite.
- Pendant le gel des fêtes, rappelle qu'on n'envoie rien et pourquoi.
- Ne lance aucun scan, n'envoie aucun message, ne modifie aucun fichier pendant /matin.
