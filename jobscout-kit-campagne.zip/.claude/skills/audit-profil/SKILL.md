---
name: audit-profil
description: Audit objectif du profil candidat (GitHub, CV maître, LinkedIn, tunnel de candidatures) avec une note sur 20 et les 3 corrections prioritaires. À lancer chaque dimanche ou après une série de refus.
disable-model-invocation: true
---

# /audit-profil

Répond à la question « mon profil est-il bon ? » avec des faits vérifiables, jamais avec une impression.
Chaque critère vaut 1 point : ✅ vérifié, ❌ à corriger, ❓ non vérifiable (demander à l'utilisateur, une seule question groupée à la fin).

## Critères

### GitHub (6 points)
Vérifier les pages publiques (`gh` si installé, sinon `curl -s https://api.github.com/...` et les README bruts sur raw.githubusercontent.com) :
1. Le repo de l'order book est public, a un README avec build, tests et benchmark reproductible.
2. Il est épinglé (demander à l'utilisateur si l'API ne permet pas de le voir).
3. Le README de NBA_Predictor n'a plus de tableau de résultats vide (aucune cellule « — »).
4. La bio et la localisation du profil ne parlent plus d'étudiant ni de Lyon.
5. Le README de NOGOMAN décrit une seule stack, sans section vide.
6. Chaque repo épinglé a une description d'une ligne.

### CV maître (6 points)
Via `GET http://127.0.0.1:3000/api/cv-template` si l'app tourne, sinon `data/mission/cv-template.F.json` :
7. Le cluster F existe.
8. Aucun crochet restant (`placeholders` vide).
9. Le CV F ne mentionne aucun outil de développement par IA.
10. Le CV F tient sur une page (dernier PDF généré dans `data/documents`, ou demander).
11. Java n'apparaît dans les compétences que si le repo du ledger est public avec des tests.
12. La ligne d'en-tête suisse mentionne le permis, la disponibilité, un niveau CECRL et Genève.

### Vitrine et réseau (4 points, déclaratifs)
13. LinkedIn : titre aligné sur le CV F et localisation Genève.
14. Lettre de référence Ampere demandée ou obtenue.
15. Au moins 3 relectures de CV par des ingénieurs en poste en Suisse.
16. « Pourquoi la finance / la Suisse » rédigé et dit à voix haute en moins de 45 secondes.

### Tunnel (4 points, base `data/jobscout.db` en lecture seule)
17. Au moins 12 candidatures ciblées sur les 7 derniers jours (hors gel des fêtes).
18. Taux de réponse ≥ 10 % sur les candidatures de plus de 14 jours (non noté sous 20 candidatures).
19. Au moins un entretien obtenu sur les 20 dernières candidatures (non noté sous 20).
20. Aucune relance en retard de plus de 3 jours.

## Sortie

1. Note sur 20, et la note précédente si `data/mission/audit.json` existe.
2. Tableau des critères (✅ / ❌ / ❓) avec la preuve en quelques mots.
3. Les 3 corrections au meilleur rapport impact / temps, avec l'id de tâche de `plan.json` si elle existe.
4. Diagnostic du tunnel selon les seuils de MISSION.md : où ça casse (CV, technique, final) ou « pas assez de données ».
5. Écrire `data/mission/audit.json` : `{ "date", "score", "items": [{ "id", "label", "status", "evidence" }], "top3": [] }`.

## Règles

- Ne jamais conclure sur la valeur de la personne. On évalue un dossier et un tunnel, qui se corrigent.
- Les faits forts du profil (voir MISSION.md) ne se notent pas : ils sont acquis. Les rappeler en une ligne seulement si l'utilisateur doute de lui.
- Ne modifier aucun fichier hors `audit.json`.
