# Journal de campagne

Entrées les plus récentes en haut. Écrit par /soir.

## 2026-11-02
- Fait : kit de campagne installé, plan et cibles posés.
- Candidatures : 0
- Réponses : aucune
- Énergie : à noter
- Blocage : aucun
- Demain, la priorité : P1-03 (order book public) si UBS est traité ce soir.
