# Mission : SWE en finance ou consulting en Suisse

Fichier personnel (dans `data/`, jamais versionné). Claude Code le lit au début de chaque session.

## Objectif

- Offre signée au plus tard le **31 janvier 2027**, démarrage visé le **1er février 2027** (mars acceptable).
- Postes : Software Engineer en banque, infrastructure de marché, négoce, éditeur bancaire, ou consulting tech.
- Lieux : Genève / Lausanne en priorité, Zurich pour les équipes anglophones.
- Atout administratif : citoyen UE, permis B ou G sans parrainage.

## Une seule histoire

Ingénieur logiciel qui construit des systèmes dont l'exactitude se vérifie :
moteur d'appariement C++17 testé par invariants, pipeline ML en production avec quality gate,
générateur de code assisté par LLM validé par AST chez Renault Group (Ampere).
Pourquoi la finance : carnet d'ordres (août–sept. 2026), ledger Java (novembre 2026), goût pour
les systèmes où une erreur coûte cher. Pourquoi la Suisse : scolarité à Genève (IIL, 2016–2020).

Deux CV seulement : cluster **F** (finance) et cluster **E** retravaillé pour le consulting.
Les clusters A, B, C, D ne servent plus pendant la campagne.

## Calendrier

| Phase | Dates | But |
|---|---|---|
| P1 Vitrine | 2–8 nov. | GitHub, CV F, LinkedIn, cibles, UBS |
| P2 Vague 1 | 9–29 nov. | Cabinets, éditeurs, infra de marché + ledger Java |
| P3 Vague 2 | 30 nov.–18 déc. | Banques + order book v2 + entretiens |
| P4 Gel | 19 déc.–4 janv. | Pas de candidature : préparation, domaine, algo |
| P5 Closing | 5–31 janv. | Relances le 5, vague 3, tours finaux, négociation |

Le recrutement suisse est quasi à l'arrêt du 19 décembre au 4 janvier : rien n'est envoyé pendant cette période.

## Règles (non négociables)

1. Une candidature = une offre lue en entier + CV F ou E + un message à une personne nommée. Jamais d'envoi en masse.
2. Rien n'est écrit sur le CV qui ne soit vrai et défendable en entretien. Les chiffres manquants restent entre crochets jusqu'à mesure.
3. Le projet Java (ledger) est écrit à la main, sans agent : il sert au live coding et à la crédibilité.
4. Le stage Ampere reste prioritaire en journée : la lettre de référence vaut plus qu'une soirée.
5. L'outil ne doit pas devenir le projet : la page Mission a un budget de 6 h, pas une minute de plus.
6. Dimanche soir libre. Un sprint de 13 semaines se gagne en tenant la distance.

## Budget de temps

Semaine : 180 min le soir (60 algo + 60 candidature + 60 projet). Samedi : 480 min. Dimanche : 300 min.

## Indicateurs et lecture du tunnel

Hebdomadaire (P2, P3, P5) : 12 candidatures ciblées, 10 messages à des personnes nommées, 2 mock interviews (dès P3).

Après 40 candidatures ciblées :
- moins de 10 % de réponses → problème de CV ou de ciblage : relancer /audit-profil ;
- des entretiens mais pas de 2e tour → préparation technique (algo, C++, Java) ;
- des tours finaux sans offre → récit « pourquoi la finance / la Suisse » et histoires STAR.

Un refus est une donnée, pas un verdict. On note l'étape (filtre automatique, recruteur, technique, final) et on corrige la bonne étape.

## Plan B (déclenché le 15 janvier si aucun tour final)

V.I.E en Suisse, filiales suisses de banques françaises, puis finance à Paris pour 1 à 2 ans avant de retenter la Suisse.
